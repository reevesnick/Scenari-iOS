//
//  NSDate-TimeAgo.h
//  NSDate-TimeAgo
//
//  Created by David Keegan on 10/13/15.
//  Copyright © 2015 Kevin Lawler. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for NSDate-TimeAgo.
FOUNDATION_EXPORT double NSDate_TimeAgoVersionNumber;

//! Project version string for NSDate-TimeAgo.
FOUNDATION_EXPORT const unsigned char NSDate_TimeAgoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NSDate_TimeAgo/PublicHeader.h>


